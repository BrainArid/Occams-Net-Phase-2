#include <iostream>                  // for std::cout
#include <utility>                   // for std::pair
#include <algorithm>                 // for std::for_each
#include <boost/graph/graph_traits.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/dijkstra_shortest_paths.hpp>

#include "Graph.h"

using namespace std;
using namespace boost;

//Arguments
char* AddrOnt;
char* AddrPPI;
char* AddrStein;

void printHelpMessage()
{
  cout << "Printing Help:" << endl << endl;
  cout << "FLAG\t\tDefault Value\tDescription" << endl;
  cout << "--num-reads1, -n1\t30000000\tSize of array used to store reads from first .bed file." << endl;
  cout << "--num-reads2, -n2\t30000000\tSize of array used to store reads from second .bed file." << endl;
  cout << "--largest-Chrom, -c\t250000000\tOverestimate of largest chromosome in bases." << endl;
  cout << "--bin-log, -l\t2\tThe base of the log scaling used to bin distance histogram output." << endl;
  cout << "--out-dir, -o\trequired\tAddress of directory to place output." << endl;
  cout << "--in-bed1,i1\trequired\tAddress of first name-sorted and multimapped-filtered .bed file." << endl;
  cout << "--in-bed2,i2\trequired\tAddress of second name-sorted and multimapped-filtered .bed file." << endl;
}

void extractArgs(int argc, char *argv[])
{
  bool printHelp = argc <= 1;

  cout << "argc = " << argc << endl;
  for(int i = 0; i < argc; i++)
    {
      cout << "argv[" << i << "] = " << argv[i] << endl;

      if(strcmp(argv[i], "--in-ppi")==0 || strcmp(argv[i], "-ip") == 0)
        {
          if(++i >= argc)
            {
              cout << "Expected input file 1 address after flag" << endl;
              printHelp = true;
            }
          else
            ifName1 = argv[i];
        }
      else if(strcmp(argv[i], "--in-steiner")==0 || strcmp(argv[i], "-is") == 0)
        {
          if(++i >= argc)
            {
              cout << "Expected input file 2 address after flag" << endl;
              printHelp = true;
            }
          else
            ifName2 = argv[i];
        }
      else if(strcmp(argv[i], "--out-dir")==0 || strcmp(argv[i], "-o") == 0)
        {
          if(++i >= argc)
            {
              cout << "Expected output directory address after flag" << endl;
              printHelp = true;
            }
          else
            oDir = argv[i];
        }
      else if(strcmp(argv[i], "--num-reads1")==0 || strcmp(argv[i], "-n1") == 0)
        {
          if(++i >= argc)
            {
              cout << "Expected number of reads in first bed file after flag" << endl;
              printHelp = true;
            }
          else
            numReads1 = atoi(argv[i]);
        }
      else if(strcmp(argv[i], "--num-reads2")==0 || strcmp(argv[i], "-n2") == 0)
        {
          if(++i >= argc)
            {
              cout << "Expected number of reads in second bed file after flag" << endl;
              printHelp = true;
            }
          else
            numReads2 = atoi(argv[i]);
        }
      else if(strcmp(argv[i], "--largest-Chrom")==0 || strcmp(argv[i], "-c") == 0)
        {
          if(++i >= argc)
            {
              cout << "Expected largest Chromosome size in bases after flag" << endl;
              printHelp = true;
            }
          else
            largestChromSize = atoi(argv[i]);
        }
      else if(strcmp(argv[i], "--bin-log")==0 || strcmp(argv[i], "-l") == 0)
        {
          if(++i >= argc)
            {
              cout << "Expected log base for distance binning after flag" << endl;
              printHelp = true;
            }
          else
            binLog = atoi(argv[i]);
        }
    }

  if(printHelp)
    printHelpMessage();
}

int main(int argc, char *argv[])
{

  string name = "PPI";
  vector<Graph::BaseEdge> edges;
  edges.push_back(make_pair(1,2));
  Graph IntrNet(name,edges,3); //Interaction Network
  cout << IntrNet << endl;

  //get parameters
  string PPIAddr, ontAddr, treeAddr;
	extractArgs(argc, argv);
	
  //construct IntrNet

  //construct steinerTree as subgraph (may not be able to assume subgraph)

  //construct ontology

  //calculate inner score and outer and middle scores

  //output scores per gene set

  return 0;
}
